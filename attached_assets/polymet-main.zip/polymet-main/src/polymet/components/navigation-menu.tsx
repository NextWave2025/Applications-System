import { Link } from "react-router-dom";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";

export default function NavigationMenuComponent() {
  return (
    <NavigationMenu className="hidden md:flex">
      <NavigationMenuList>
        <NavigationMenuItem>
          <NavigationMenuTrigger>Why UAE</NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
              <div className="space-y-2">
                <h4 className="font-medium leading-none">
                  World-Class Education
                </h4>
                <p className="text-sm text-muted-foreground">
                  Internationally recognized universities with top
                  accreditations
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Global Hub</h4>
                <p className="text-sm text-muted-foreground">
                  Strategic location connecting East and West
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Career Growth</h4>
                <p className="text-sm text-muted-foreground">
                  Exceptional job opportunities in a growing economy
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Quality of Life</h4>
                <p className="text-sm text-muted-foreground">
                  Safe environment with modern infrastructure
                </p>
              </div>
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuTrigger>For Agents</NavigationMenuTrigger>
          <NavigationMenuContent>
            <div className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
              <div className="space-y-2">
                <h4 className="font-medium leading-none">
                  Commission Structure
                </h4>
                <p className="text-sm text-muted-foreground">
                  Competitive rates with fast payouts
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Marketing Support</h4>
                <p className="text-sm text-muted-foreground">
                  Access to branded materials and campaigns
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Training</h4>
                <p className="text-sm text-muted-foreground">
                  Comprehensive onboarding and regular updates
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium leading-none">Dashboard</h4>
                <p className="text-sm text-muted-foreground">
                  Track applications and commissions in real-time
                </p>
              </div>
            </div>
          </NavigationMenuContent>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuLink asChild className={navigationMenuTriggerStyle()}>
            <Link to="/programs">Programs</Link>
          </NavigationMenuLink>
        </NavigationMenuItem>
        <NavigationMenuItem>
          <NavigationMenuLink asChild className={navigationMenuTriggerStyle()}>
            <Link to="#contact">Contact</Link>
          </NavigationMenuLink>
        </NavigationMenuItem>
      </NavigationMenuList>
    </NavigationMenu>
  );
}
